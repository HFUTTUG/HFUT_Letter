## 合肥工业大学信纸 LaTeX 模板

[![Tex Build Test](https://github.com/HFUTTUG/HFUT_Letter/actions/workflows/tex_build_test.yml/badge.svg)](https://github.com/HFUTTUG/HFUT_Letter/actions/workflows/tex_build_test.yml)
[![Homepage Deploy](https://github.com/HFUTTUG/HFUT_Letter/actions/workflows/page_deploy.yml/badge.svg)](https://github.com/HFUTTUG/HFUT_Letter/actions/workflows/page_deploy.yml)
![visitors](https://visitor-badge.glitch.me/badge?page_id=HFUTTUG.HFUT_Letter)


项目主页：[HFUT_Letter Github Page](https://HFUTTUG.github.io/HFUT_Letter)

项目详细信息可通过 [**项目主页**](https://HFUTTUG.github.io/HFUT_Letter) 查看。